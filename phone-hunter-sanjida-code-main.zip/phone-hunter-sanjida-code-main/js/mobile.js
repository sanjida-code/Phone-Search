document.getElementById('error-message').style.display = 'none';
const searchPhone = () => {
    const searchField = document.getElementById('search-field');
    const searchText = searchField.value;
    // clear data
    searchField.value = '';
    document.getElementById('error-message').style.display = 'none';
    if (searchText == '') {
        console.log('please write something to display') ;
    }
    else {
       // load data
        const url = `https://openapi.programming-hero.com/api/phones?search=${searchText}`;
        // console.log(url);
        fetch(url)
            .then(res => res.json())
            .then(dataof => displaySearchResult(dataof.data));
            // .catch(error => displayError(error));}
    }
}

const displayError = error => {
    document.getElementById('error-message').style.display = 'block';
}

const displaySearchResult = data => {
    console.log(data);
    const searchResult = document.getElementById('search-result');
    searchResult.textContent = '';
    if (data.length == 0) {
        console.log('no result found');
    }
    data.forEach (datas => {
        const div = document.createElement('div');
        div.classList.add('col');
        div.innerHTML = `
        <div class="col">
            <div class="card">
                <img src="${datas.image}" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Name: ${datas.phone_name}</h5>
                    <h5 class="card-title">Release Date: ${datas.releaseDate}</h5>
                    <h5 class="card-title">Price: $1000</h5>
                    <h4 class="card-title">Brand: ${datas.brand}</h4>
                    <button onclick="loadPhoneDetail(${datas.slug})" type="button" id="button-search">Details</button>
                </div>
            </div>
        </div>
        `;
        searchResult.appendChild(div);
    });
};

const loadPhoneDetail = phoneId => {
    const url = `https://www.themealdb.com/api/json/v1/1/lookup.php?${phoneId}`;
    fetch(url)
        .then(res => res.json())
        .then(dataof => displayPhoneDetail(dataof.data[0]));
}
const displayPhoneDetail = datas => {
    console.log(datas);
    const phoneDetails = document.getElementById('Phone-details');
    phoneDetails.textContent =' ';
    const div = document.createElement('div');
    div.classList.add('card');
    div.innerHTML = `
    <img src="${datas.image}" class="card-img-top" alt="...">
    <div class="card-body">
        <h5 class="card-title">${datas.phone_name}</h5>
        <h5 class="card-title">Release Date: ${datas.releaseDate}</h5>
        <h5 class="card-title">Price: $1000</h5>
        <h4 class="card-title">Brand: ${datas.brand}</h4>
        <p class="card-text">${datas.mainFeatures}</p>
        <a href="${datas.storage}" class="btn btn-primary">Go somewhere</a>
    </div>
    `;
    phoneDetails.appendChild(div);
}